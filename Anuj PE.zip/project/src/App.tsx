import React, { useState } from 'react';
import { BookOpen, Calculator, ChevronRight, Lightbulb, Ruler, Zap, ArrowLeft, Beaker, Compass, Brain, Microscope, Atom, Gauge, Wrench, Cog, Rocket } from 'lucide-react';

// Landing page component
const LandingPage = ({ onGetStarted }: { onGetStarted: () => void }) => (
  <div className="min-h-screen bg-gradient-to-br from-purple-800 via-indigo-800 to-blue-700 text-white">
    <div className="max-w-7xl mx-auto px-4 py-16 sm:px-6 lg:px-8">
      <div className="text-center">
        <h1 className="text-5xl md:text-6xl font-extrabold mb-8 bg-clip-text text-transparent bg-gradient-to-r from-blue-200 via-purple-200 to-pink-200">
          Master Engineering Formulas
        </h1>
        <p className="text-xl md:text-2xl text-blue-200 mb-12 max-w-3xl mx-auto">
          Your comprehensive guide to engineering calculations. Access over 50 essential formulas across multiple engineering disciplines.
        </p>
        <button
          onClick={onGetStarted}
          className="bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white text-lg px-8 py-4 rounded-full font-semibold transition-all duration-300 transform hover:scale-105 hover:shadow-xl"
        >
          Get Started →
        </button>
      </div>

      <div className="mt-24 grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 text-center">
          <div className="bg-purple-500/20 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
            <Brain className="h-8 w-8" />
          </div>
          <h3 className="text-xl font-semibold mb-2">Easy to Understand</h3>
          <p className="text-blue-200">Clear explanations and practical examples for every formula</p>
        </div>
        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 text-center">
          <div className="bg-purple-500/20 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
            <Microscope className="h-8 w-8" />
          </div>
          <h3 className="text-xl font-semibold mb-2">Comprehensive Coverage</h3>
          <p className="text-blue-200">From basic principles to advanced calculations</p>
        </div>
        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 text-center">
          <div className="bg-purple-500/20 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
            <Atom className="h-8 w-8" />
          </div>
          <h3 className="text-xl font-semibold mb-2">Multiple Disciplines</h3>
          <p className="text-blue-200">Covers all major engineering fields</p>
        </div>
      </div>

      <div className="mt-32">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
          <div>
            <h2 className="text-3xl font-bold mb-6">Why Choose Our Formula Explainer?</h2>
            <div className="space-y-4">
              <div className="flex items-start">
                <div className="bg-purple-500/20 p-2 rounded-lg mr-4">
                  <Calculator className="h-6 w-6" />
                </div>
                <div>
                  <h3 className="font-semibold mb-1">Interactive Calculations</h3>
                  <p className="text-blue-200">Practice with real-world examples and verify your understanding</p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="bg-purple-500/20 p-2 rounded-lg mr-4">
                  <BookOpen className="h-6 w-6" />
                </div>
                <div>
                  <h3 className="font-semibold mb-1">Detailed Explanations</h3>
                  <p className="text-blue-200">Each formula comes with comprehensive explanations and practical applications</p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="bg-purple-500/20 p-2 rounded-lg mr-4">
                  <Compass className="h-6 w-6" />
                </div>
                <div>
                  <h3 className="font-semibold mb-1">Multiple Engineering Fields</h3>
                  <p className="text-blue-200">Cover various engineering disciplines from mechanical to electrical</p>
                </div>
              </div>
            </div>
          </div>
          <div className="relative">
            <img
              src="https://images.unsplash.com/photo-1581092918056-0c4c3acd3789?auto=format&fit=crop&q=80&w=800"
              alt="Engineering calculations"
              className="rounded-xl shadow-2xl"
            />
            <div className="absolute -bottom-6 -right-6 bg-white/10 backdrop-blur-lg rounded-xl p-4 shadow-xl">
              <p className="text-lg font-semibold">50+ Formulas</p>
              <p className="text-blue-200">Constantly updated</p>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-32">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold mb-4">Featured Engineering Fields</h2>
          <p className="text-blue-200 max-w-2xl mx-auto">Explore formulas across different engineering disciplines</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <div className="relative group">
            <img
              src="https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&q=80&w=800"
              alt="Mechanical Engineering"
              className="rounded-xl brightness-50 group-hover:brightness-75 transition-all duration-300"
            />
            <div className="absolute bottom-0 left-0 right-0 p-6">
              <h3 className="text-xl font-bold mb-2">Mechanical Engineering</h3>
              <p className="text-blue-200">Dynamics, thermodynamics, and material mechanics</p>
            </div>
          </div>
          <div className="relative group">
            <img
              src="https://images.unsplash.com/photo-1498084393753-b411b2d26b34?auto=format&fit=crop&q=80&w=800"
              alt="Electrical Engineering"
              className="rounded-xl brightness-50 group-hover:brightness-75 transition-all duration-300"
            />
            <div className="absolute bottom-0 left-0 right-0 p-6">
              <h3 className="text-xl font-bold mb-2">Electrical Engineering</h3>
              <p className="text-blue-200">Circuit analysis, electromagnetics, and power systems</p>
            </div>
          </div>
          <div className="relative group">
            <img
              src="https://images.unsplash.com/photo-1497436072909-60f360e1d4b1?auto=format&fit=crop&q=80&w=800"
              alt="Civil Engineering"
              className="rounded-xl brightness-50 group-hover:brightness-75 transition-all duration-300"
            />
            <div className="absolute bottom-0 left-0 right-0 p-6">
              <h3 className="text-xl font-bold mb-2">Civil Engineering</h3>
              <p className="text-blue-200">Structural analysis, fluid mechanics, and material properties</p>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-32 text-center">
        <h2 className="text-3xl font-bold mb-6">Ready to Master Engineering Formulas?</h2>
        <p className="text-blue-200 max-w-2xl mx-auto mb-8">
          Join thousands of engineering students who are already improving their understanding of engineering principles
        </p>
        <button
          onClick={onGetStarted}
          className="bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white text-lg px-8 py-4 rounded-full font-semibold transition-all duration-300 transform hover:scale-105 hover:shadow-xl"
        >
          Start Learning Now →
        </button>
      </div>
    </div>
  </div>
);

// Engineering categories with their formulas
const engineeringData = {
  electrical: {
    name: "Electrical Engineering",
    icon: Zap,
    description: "Explore fundamental electrical engineering formulas and concepts",
    formulas: [
      {
        name: "Ohm's Law",
        equation: "V = I × R",
        variables: {
          "V": "Voltage (Volts)",
          "I": "Current (Amperes)",
          "R": "Resistance (Ohms)"
        },
        explanation: "Ohm's Law describes the relationship between voltage, current, and resistance in an electrical circuit. The voltage across a conductor is directly proportional to the current flowing through it.",
        example: "If a circuit has a current of 2A and resistance of 5Ω, the voltage would be: V = 2A × 5Ω = 10V"
      },
      {
        name: "Power",
        equation: "P = V × I",
        variables: {
          "P": "Power (Watts)",
          "V": "Voltage (Volts)",
          "I": "Current (Amperes)"
        },
        explanation: "This formula calculates the electrical power in a circuit. Power is the rate at which electrical energy is transferred.",
        example: "For a device operating at 120V and drawing 2A: P = 120V × 2A = 240W"
      },
      {
        name: "Capacitive Reactance",
        equation: "Xc = 1 / (2π × f × C)",
        variables: {
          "Xc": "Capacitive Reactance (Ohms)",
          "f": "Frequency (Hertz)",
          "C": "Capacitance (Farads)"
        },
        explanation: "Capacitive reactance is the resistance offered by a capacitor to AC current. It varies inversely with frequency and capacitance.",
        example: "For a 100μF capacitor at 60Hz: Xc = 1 / (2π × 60 × 100×10⁻⁶) = 26.5Ω"
      },
      {
        name: "Inductive Reactance",
        equation: "XL = 2π × f × L",
        variables: {
          "XL": "Inductive Reactance (Ohms)",
          "f": "Frequency (Hertz)",
          "L": "Inductance (Henries)"
        },
        explanation: "Inductive reactance is the opposition to current flow in an inductor. It increases with frequency and inductance.",
        example: "For a 50mH inductor at 1kHz: XL = 2π × 1000 × 0.05 = 314.16Ω"
      },
      {
        name: "Resonant Frequency",
        equation: "f = 1 / (2π × √(LC))",
        variables: {
          "f": "Resonant Frequency (Hertz)",
          "L": "Inductance (Henries)",
          "C": "Capacitance (Farads)"
        },
        explanation: "The resonant frequency is where inductive and capacitive reactances are equal in magnitude.",
        example: "For L = 1mH and C = 10μF: f = 1 / (2π × √(0.001 × 10×10⁻⁶)) = 1,592Hz"
      }
    ]
  },
  mechanical: {
    name: "Mechanical Engineering",
    icon: Cog,
    description: "Master essential mechanical engineering equations and principles",
    formulas: [
      {
        name: "Force",
        equation: "F = m × a",
        variables: {
          "F": "Force (Newtons)",
          "m": "Mass (Kilograms)",
          "a": "Acceleration (m/s²)"
        },
        explanation: "Newton's Second Law of Motion states that force equals mass times acceleration. This fundamental equation is used to calculate the force needed to accelerate an object.",
        example: "To accelerate a 2kg mass at 5 m/s²: F = 2kg × 5m/s² = 10N"
      },
      {
        name: "Kinetic Energy",
        equation: "KE = ½ × m × v²",
        variables: {
          "KE": "Kinetic Energy (Joules)",
          "m": "Mass (Kilograms)",
          "v": "Velocity (m/s)"
        },
        explanation: "Kinetic energy is the energy possessed by an object due to its motion. This formula helps calculate the energy of moving objects.",
        example: "A 1000kg car moving at 15 m/s has KE = ½ × 1000kg × (15m/s)² = 112,500J"
      },
      {
        name: "Work Done",
        equation: "W = F × d × cos(θ)",
        variables: {
          "W": "Work Done (Joules)",
          "F": "Force (Newtons)",
          "d": "Distance (meters)",
          "θ": "Angle between force and displacement"
        },
        explanation: "Work is the product of force and displacement in the direction of force. The angle between force and displacement affects the work done.",
        example: "Pushing a box with 50N force over 2m at 30°: W = 50N × 2m × cos(30°) = 86.6J"
      },
      {
        name: "Momentum",
        equation: "p = m × v",
        variables: {
          "p": "Momentum (kg⋅m/s)",
          "m": "Mass (Kilograms)",
          "v": "Velocity (m/s)"
        },
        explanation: "Linear momentum is a measure of the motion of an object, considering both its mass and velocity.",
        example: "A 5kg object moving at 3 m/s has momentum: p = 5kg × 3m/s = 15kg⋅m/s"
      },
      {
        name: "Power",
        equation: "P = W / t",
        variables: {
          "P": "Power (Watts)",
          "W": "Work Done (Joules)",
          "t": "Time (Seconds)"
        },
        explanation: "Power is the rate of doing work or transferring energy. It measures how quickly work is performed.",
        example: "If 1000J of work is done in 5 seconds: P = 1000J / 5s = 200W"
      }
    ]
  },
  civil: {
    name: "Civil Engineering",
    icon: Ruler,
    description: "Understand structural and construction engineering calculations",
    formulas: [
      {
        name: "Beam Deflection",
        equation: "δ = (P × L³) / (48 × E × I)",
        variables: {
          "δ": "Deflection (meters)",
          "P": "Load (Newtons)",
          "L": "Length (meters)",
          "E": "Elastic Modulus (Pa)",
          "I": "Moment of Inertia (m⁴)"
        },
        explanation: "This formula calculates the maximum deflection of a simply supported beam under a point load at the center. It's crucial for structural design and analysis.",
        example: "For a steel beam (E=200GPa) with I=4×10⁻⁶m⁴, L=2m, P=1000N: δ = (1000×2³)/(48×200×10⁹×4×10⁻⁶) = 0.208mm"
      },
      {
        name: "Stress",
        equation: "σ = F / A",
        variables: {
          "σ": "Stress (Pascal)",
          "F": "Force (Newtons)",
          "A": "Area (m²)"
        },
        explanation: "Stress is the internal force per unit area within a material. This formula is fundamental in determining material strength requirements.",
        example: "A force of 10kN on a cross-section of 100mm²: σ = 10000N / 0.0001m² = 100MPa"
      },
      {
        name: "Bending Moment",
        equation: "M = (w × L²) / 8",
        variables: {
          "M": "Maximum Bending Moment (N⋅m)",
          "w": "Uniform Load (N/m)",
          "L": "Beam Length (m)"
        },
        explanation: "The maximum bending moment for a uniformly loaded simply supported beam occurs at the center.",
        example: "For a 6m beam with 2kN/m load: M = (2000 × 6²) / 8 = 9000N⋅m"
      },
      {
        name: "Shear Force",
        equation: "V = w × L / 2",
        variables: {
          "V": "Maximum Shear Force (N)",
          "w": "Uniform Load (N/m)",
          "L": "Beam Length (m)"
        },
        explanation: "The maximum shear force for a uniformly loaded simply supported beam occurs at the supports.",
        example: "For a 4m beam with 3kN/m load: V = 3000 × 4 / 2 = 6000N"
      }
    ]
  },
  chemical: {
    name: "Chemical Engineering",
    icon: Beaker,
    description: "Learn essential chemical process and reaction formulas",
    formulas: [
      {
        name: "Ideal Gas Law",
        equation: "PV = nRT",
        variables: {
          "P": "Pressure (Pascal)",
          "V": "Volume (m³)",
          "n": "Number of moles",
          "R": "Gas constant (8.314 J/mol·K)",
          "T": "Temperature (Kelvin)"
        },
        explanation: "The ideal gas law describes the relationship between pressure, volume, temperature, and the amount of gas in a system.",
        example: "For 2 moles of gas at 300K in 0.1m³: P = (2×8.314×300)/0.1 = 49,884 Pa"
      },
      {
        name: "Mass Balance",
        equation: "ṁin = ṁout + ṁacc",
        variables: {
          "ṁin": "Mass flow rate in (kg/s)",
          "ṁout": "Mass flow rate out (kg/s)",
          "ṁacc": "Mass accumulation rate (kg/s)"
        },
        explanation: "The mass balance equation ensures conservation of mass in a system. For steady-state operation, accumulation is zero.",
        example: "If mass flow in is 5 kg/s and accumulation is 1 kg/s: ṁout = 5 - 1 = 4 kg/s"
      },
      {
        name: "Reaction Rate",
        equation: "r = k × [A]ᵃ × [B]ᵇ",
        variables: {
          "r": "Reaction rate (mol/L·s)",
          "k": "Rate constant",
          "[A], [B]": "Concentrations (mol/L)",
          "a, b": "Reaction orders"
        },
        explanation: "The reaction rate equation describes how quickly reactants are converted to products based on concentrations.",
        example: "For a second-order reaction with k=0.1 L/mol·s and [A]=2M: r = 0.1 × (2)² = 0.4 mol/L·s"
      }
    ]
  },
  aerospace: {
    name: "Aerospace Engineering",
    icon: Rocket,
    description: "Explore aerodynamics and spacecraft engineering formulas",
    formulas: [
      {
        name: "Lift Force",
        equation: "L = ½ × ρ × v² × CL × A",
        variables: {
          "L": "Lift Force (N)",
          "ρ": "Air Density (kg/m³)",
          "v": "Velocity (m/s)",
          "CL": "Lift Coefficient",
          "A": "Wing Area (m²)"
        },
        explanation: "The lift force equation calculates the upward force generated by an aircraft's wings.",
        example: "For ρ=1.225 kg/m³, v=100 m/s, CL=1.5, A=30m²: L = ½ × 1.225 × 100² × 1.5 × 30 = 275,625N"
      },
      {
        name: "Drag Force",
        equation: "D = ½ × ρ × v² × CD × A",
        variables: {
          "D": "Drag Force (N)",
          "ρ": "Air Density (kg/m³)",
          "v": "Velocity (m/s)",
          "CD": "Drag Coefficient",
          "A": "Reference Area (m²)"
        },
        explanation: "The drag force equation determines the resistance force on an object moving through a fluid.",
        example: "For ρ=1.225 kg/m³, v=50 m/s, CD=0.3, A=2m²: D = ½ × 1.225 × 50² × 0.3 × 2 = 459.375N"
      }
    ]
  },
  thermodynamics: {
    name: "Thermodynamics",
    icon: Gauge,
    description: "Study heat transfer and energy conversion principles",
    formulas: [
      {
        name: "Heat Transfer",
        equation: "Q = m × c × ΔT",
        variables: {
          "Q": "Heat Energy (Joules)",
          "m": "Mass (kg)",
          "c": "Specific Heat Capacity (J/kg·K)",
          "ΔT": "Temperature Change (K)"
        },
        explanation: "This equation calculates the heat energy required to change the temperature of a substance.",
        example: "To heat 2kg of water (c=4186 J/kg·K) by 30K: Q = 2 × 4186 × 30 = 251,160J"
      },
      {
        name: "Thermal Conductivity",
        equation: "q = -k × A × (dT/dx)",
        variables: {
          "q": "Heat Transfer Rate (W)",
          "k": "Thermal Conductivity (W/m·K)",
          "A": "Area (m²)",
          "dT/dx": "Temperature Gradient (K/m)"
        },
        explanation: "Fourier's law of heat conduction describes heat transfer through a material.",
        example: "For k=0.6 W/m·K, A=2m², temperature gradient=100K/m: q = -0.6 × 2 × (-100) = 120W"
      }
    ]
  }
};

function App() {
  const [showLanding, setShowLanding] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedFormula, setSelectedFormula] = useState<any | null>(null);

  if (showLanding) {
    return <LandingPage onGetStarted={() => setShowLanding(false)} />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      <header className="bg-white shadow-lg border-b border-indigo-100">
        <div className="max-w-7xl mx-auto px-4 py-6 sm:px-6 lg:px-8 flex items-center justify-between">
          <div className="flex items-center">
            <BookOpen className="h-10 w-10 text-indigo-600" />
            <div className="ml-4">
              <h1 className="text-3xl font-bold text-gray-900">Engineering Formula Explainer</h1>
              <p className="text-sm text-gray-600 mt-1">Master engineering concepts with interactive formula explanations</p>
            </div>
          </div>
          {selectedCategory && (
            <button
              onClick={() => {
                setSelectedCategory(null);
                setSelectedFormula(null);
              }}
              className="text-indigo-600 hover:text-indigo-800 flex items-center"
            >
              <ArrowLeft className="h-5 w-5 mr-2" />
              All Categories
            </button>
          )}
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-12 sm:px-6 lg:px-8">
        {!selectedCategory ? (
          <>
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Engineering Fields</h2>
              <p className="text-gray-600 max-w-2xl mx-auto">
                Choose your field of study to explore relevant formulas and calculations
              </p>
            </div>
            <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
              {Object.entries(engineeringData).map(([key, category]) => {
                const IconComponent = category.icon;
                return (
                  <button
                    key={key}
                    onClick={() => setSelectedCategory(key)}
                    className="bg-white p-8 rounded-xl shadow-md hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 text-left group"
                  >
                    <div className="flex items-center justify-between">
                      <div className="bg-indigo-50 p-4 rounded-2xl group-hover:bg-indigo-100 transition-colors duration-300">
                        <IconComponent className="h-10 w-10 text-indigo-600" />
                      </div>
                      <div className="bg-indigo-50 rounded-full px-3 py-1 text-sm text-indigo-600 font-medium">
                        {category.formulas.length} formulas
                      </div>
                    </div>
                    <h2 className="mt-6 text-2xl font-semibold text-gray-900">{category.name}</h2>
                    <p className="mt-2 text-gray-600">{category.description}</p>
                    <div className="mt-4 flex items-center text-indigo-600 font-medium">
                      Explore formulas
                      <ChevronRight className="h-5 w-5 ml-1 group-hover:translate-x-1 transition-transform duration-300" />
                    </div>
                  </button>
                );
              })}
            </div>
          </>
        ) : !selectedFormula ? (
          <div>
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                {engineeringData[selectedCategory as keyof typeof engineeringData].name} Formulas
              </h2>
              <p className="text-gray-600 max-w-2xl mx-auto">
                Select a formula to view detailed explanations and examples
              </p>
            </div>
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {engineeringData[selectedCategory as keyof typeof engineeringData].formulas.map((formula, index) => (
                <button
                  key={index}
                  onClick={() => setSelectedFormula(formula)}
                  className="bg-white p-6 rounded-xl shadow-md hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 text-left group"
                >
                  <div className="bg-indigo-50 w-fit p-3 rounded-lg group-hover:bg-indigo-100 transition-colors duration-300">
                    <Lightbulb className="h-6 w-6 text-indigo-600" />
                  </div>
                  <h3 className="mt-4 text-xl font-semibold text-gray-900">{formula.name}</h3>
                  <p className="mt-3 text-2xl font-mono text-indigo-600 bg-indigo-50 p-3 rounded-lg group-hover:bg-indigo-100 transition-colors duration-300">
                    {formula.equation}
                  </p>
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="max-w-4xl mx-auto">
            <button
              onClick={() => setSelectedFormula(null)}
              className="mb-8 text-indigo-600 hover:text-indigo-800 flex items-center group"
            >
              <ArrowLeft className="h-5 w-5 mr-2 transform group-hover:-translate-x-1 transition-transform duration-300" />
              Back to Formulas
            </button>
            <div className="bg-white rounded-xl shadow-lg p-8">
              <h2 className="text-3xl font-bold text-gray-900 mb-6">{selectedFormula.name}</h2>
              <div className="text-4xl font-mono text-indigo-600 bg-indigo-50 p-6 rounded-xl mb-8 text-center">
                {selectedFormula.equation}
              </div>
              
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Variables:</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
                {Object.entries(selectedFormula.variables).map(([symbol, description]) => (
                  <div key={symbol} className="bg-gray-50 p-4 rounded-xl border border-gray-100 flex items-center">
                    <span className="font-mono text-xl text-indigo-600 min-w-[30px]">{symbol}</span>
                    <span className="ml-3 text-gray-700">= {description}</span>
                  </div>
                ))}
              </div>

              <h3 className="text-xl font-semibold text-gray-900 mb-4">Explanation:</h3>
              <p className="text-gray-700 leading-relaxed text-lg mb-8">{selectedFormula.explanation}</p>

              <h3 className="text-xl font-semibold text-gray-900 mb-4">Example:</h3>
              <div className="bg-green-50 p-6 rounded-xl border border-green-100">
                <p className="text-gray-700 leading-relaxed">{selectedFormula.example}</p>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

export default App;

export default App